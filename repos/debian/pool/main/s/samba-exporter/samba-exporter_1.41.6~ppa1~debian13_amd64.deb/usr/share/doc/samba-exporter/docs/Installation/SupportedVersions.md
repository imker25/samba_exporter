# Supported Versions

## Debian based

**Ubuntu:**

| Version | Code Name | Supported |
|---------|-----------|-----------|
| Ubnutu 20.04   | Focal Fossa | no |
| Ubnutu 21.04   | Hirsute Hippo | no |
| Ubnutu 21.10   | Impish Indri | no |
| Ubnutu 22.04   | Jammy Jellyfish | no |
| Ubnutu 22.10  | Kinetic Kudu | no |
| Ubnutu 23.04  | Lunar Lobster | no |
| Ubnutu 23.10  | Mantic Minotaur | no |
| Ubnutu 24.04  | Noble Numbat | yes |
| Ubnuntu 24.10 | Oracular Oriole | no |
| Ubnuntu 25.04 | Plucky Puffin | no |
| Ubnuntu 25.10 | Questing Quokka | no |
| Ubnuntu 26.04 | Resolute Raccoon | yes |
| Ubnuntu 26.10 | Stonking Stingray | yes |
| Ubnuntu 27.04 | - | planed |

---

**Debian:**

| Version | Code Name | Supported |
|---------|-----------|-----------|
| Debian 10  | Buster | no |
| Debian 11   | Bullseye | no |
| Debian 12  | Bookworm | yes |
| Debian 13  | Trixie | yes |
| Debian 14  | Forky | planed |
| Debian testing  | Duke | no |

## RPM based

**Fedora:**

| Version | Release | Supported |
|---------|-----------|-----------|
| Fedora 28  | 2018-05-01 | yes |
| Fedora 29  | 2018-10-30 | no |
| Fedora 30  | 2019-04-29 | no |
| Fedora 31  | 2019-10-29 | no |
| Fedora 32  | 2020-04-28 | no |
| Fedora 33  | 2020-10-28 | no |
| Fedora 34  | 2021-04-27 | no |
| Fedora 35  | 2021-11-02 | yes |
| Fedora 36   | 2022-04-19 | no |
| Fedora 37   | 2022-11-15 | no |
| Fedora 38   | 2023-04-25 | no |
| Fedora 39   | 2023-10-24 | no |
| Fedora 40   | 2024-04-23 | no |
| Fedora 41   | 2024-10-29 | no |
| Fedora 42   | 2025-04-22 | no |
| Fedora 43   | 2025-10-28 | no |
| Fedora 44   | 2026-04-28 | yes |
| Fedora 45   | 2026-11-03 | yes |
| Fedora 46   | XXX | planed |

---

**CentOS Stream:**

| Version | Release | Supported |
|---------|-----------|-----------|
| CentOS Stream| 8 | yes |
| CentOS Stream| 9 | yes |

---

**Red Hat Enterprise Linux:**

| Version | Release | Supported |
|---------|-----------|-----------|
| RHEL 8  | 2019-05-07 | yes |
| RHEL 9  | 2022-05-19 | yes |

---
