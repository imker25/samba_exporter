# Supported Versions

**Ubuntu:**

| Version | Code Name | Supported |
|---------|-----------|-----------|
| Ubnutu 20.04   | Focal Fossa | yes |
| Ubnutu 21.04   | Hirsute Hippo | no |
| Ubnutu 21.10   | Impish Indri | yes |

**Debian:**

| Version | Code Name | Supported |
|---------|-----------|-----------|
| Debian 10  | Buster | yes |
| Debian 11   | Bullseye | yes |
| Debian testing  | Bookworm | no |

